import employmentStatuses from './employment-statuses'
import militaryRanks from './military-ranks'
import banks from './banks'
import parentsStatuses from './parents-statuses'
import maritalStatuses from './marital-statuses'
import martyrs from './martyrs'
import jobGrades from './job-grades'
import permissions from './permissions'
const api = {
    employmentStatuses: Object.assign(employmentStatuses, employmentStatuses),
militaryRanks: Object.assign(militaryRanks, militaryRanks),
banks: Object.assign(banks, banks),
parentsStatuses: Object.assign(parentsStatuses, parentsStatuses),
maritalStatuses: Object.assign(maritalStatuses, maritalStatuses),
martyrs: Object.assign(martyrs, martyrs),
jobGrades: Object.assign(jobGrades, jobGrades),
permissions: Object.assign(permissions, permissions),
}

export default api