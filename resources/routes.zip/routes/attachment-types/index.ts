import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\AttachmentTypeController::index
 * @see app/Http/Controllers/AttachmentTypeController.php:15
 * @route '/attachment-types'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/attachment-types',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttachmentTypeController::index
 * @see app/Http/Controllers/AttachmentTypeController.php:15
 * @route '/attachment-types'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentTypeController::index
 * @see app/Http/Controllers/AttachmentTypeController.php:15
 * @route '/attachment-types'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttachmentTypeController::index
 * @see app/Http/Controllers/AttachmentTypeController.php:15
 * @route '/attachment-types'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttachmentTypeController::index
 * @see app/Http/Controllers/AttachmentTypeController.php:15
 * @route '/attachment-types'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttachmentTypeController::index
 * @see app/Http/Controllers/AttachmentTypeController.php:15
 * @route '/attachment-types'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttachmentTypeController::index
 * @see app/Http/Controllers/AttachmentTypeController.php:15
 * @route '/attachment-types'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AttachmentTypeController::create
 * @see app/Http/Controllers/AttachmentTypeController.php:27
 * @route '/attachment-types/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/attachment-types/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttachmentTypeController::create
 * @see app/Http/Controllers/AttachmentTypeController.php:27
 * @route '/attachment-types/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentTypeController::create
 * @see app/Http/Controllers/AttachmentTypeController.php:27
 * @route '/attachment-types/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttachmentTypeController::create
 * @see app/Http/Controllers/AttachmentTypeController.php:27
 * @route '/attachment-types/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttachmentTypeController::create
 * @see app/Http/Controllers/AttachmentTypeController.php:27
 * @route '/attachment-types/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttachmentTypeController::create
 * @see app/Http/Controllers/AttachmentTypeController.php:27
 * @route '/attachment-types/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttachmentTypeController::create
 * @see app/Http/Controllers/AttachmentTypeController.php:27
 * @route '/attachment-types/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\AttachmentTypeController::store
 * @see app/Http/Controllers/AttachmentTypeController.php:35
 * @route '/attachment-types'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/attachment-types',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AttachmentTypeController::store
 * @see app/Http/Controllers/AttachmentTypeController.php:35
 * @route '/attachment-types'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentTypeController::store
 * @see app/Http/Controllers/AttachmentTypeController.php:35
 * @route '/attachment-types'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AttachmentTypeController::store
 * @see app/Http/Controllers/AttachmentTypeController.php:35
 * @route '/attachment-types'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AttachmentTypeController::store
 * @see app/Http/Controllers/AttachmentTypeController.php:35
 * @route '/attachment-types'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AttachmentTypeController::show
 * @see app/Http/Controllers/AttachmentTypeController.php:50
 * @route '/attachment-types/{attachment_type}'
 */
export const show = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/attachment-types/{attachment_type}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttachmentTypeController::show
 * @see app/Http/Controllers/AttachmentTypeController.php:50
 * @route '/attachment-types/{attachment_type}'
 */
show.url = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attachment_type: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    attachment_type: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        attachment_type: args.attachment_type,
                }

    return show.definition.url
            .replace('{attachment_type}', parsedArgs.attachment_type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentTypeController::show
 * @see app/Http/Controllers/AttachmentTypeController.php:50
 * @route '/attachment-types/{attachment_type}'
 */
show.get = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttachmentTypeController::show
 * @see app/Http/Controllers/AttachmentTypeController.php:50
 * @route '/attachment-types/{attachment_type}'
 */
show.head = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttachmentTypeController::show
 * @see app/Http/Controllers/AttachmentTypeController.php:50
 * @route '/attachment-types/{attachment_type}'
 */
    const showForm = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttachmentTypeController::show
 * @see app/Http/Controllers/AttachmentTypeController.php:50
 * @route '/attachment-types/{attachment_type}'
 */
        showForm.get = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttachmentTypeController::show
 * @see app/Http/Controllers/AttachmentTypeController.php:50
 * @route '/attachment-types/{attachment_type}'
 */
        showForm.head = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\AttachmentTypeController::edit
 * @see app/Http/Controllers/AttachmentTypeController.php:60
 * @route '/attachment-types/{attachment_type}/edit'
 */
export const edit = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/attachment-types/{attachment_type}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttachmentTypeController::edit
 * @see app/Http/Controllers/AttachmentTypeController.php:60
 * @route '/attachment-types/{attachment_type}/edit'
 */
edit.url = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attachment_type: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    attachment_type: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        attachment_type: args.attachment_type,
                }

    return edit.definition.url
            .replace('{attachment_type}', parsedArgs.attachment_type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentTypeController::edit
 * @see app/Http/Controllers/AttachmentTypeController.php:60
 * @route '/attachment-types/{attachment_type}/edit'
 */
edit.get = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttachmentTypeController::edit
 * @see app/Http/Controllers/AttachmentTypeController.php:60
 * @route '/attachment-types/{attachment_type}/edit'
 */
edit.head = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttachmentTypeController::edit
 * @see app/Http/Controllers/AttachmentTypeController.php:60
 * @route '/attachment-types/{attachment_type}/edit'
 */
    const editForm = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttachmentTypeController::edit
 * @see app/Http/Controllers/AttachmentTypeController.php:60
 * @route '/attachment-types/{attachment_type}/edit'
 */
        editForm.get = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttachmentTypeController::edit
 * @see app/Http/Controllers/AttachmentTypeController.php:60
 * @route '/attachment-types/{attachment_type}/edit'
 */
        editForm.head = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\AttachmentTypeController::update
 * @see app/Http/Controllers/AttachmentTypeController.php:70
 * @route '/attachment-types/{attachment_type}'
 */
export const update = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/attachment-types/{attachment_type}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\AttachmentTypeController::update
 * @see app/Http/Controllers/AttachmentTypeController.php:70
 * @route '/attachment-types/{attachment_type}'
 */
update.url = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attachment_type: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    attachment_type: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        attachment_type: args.attachment_type,
                }

    return update.definition.url
            .replace('{attachment_type}', parsedArgs.attachment_type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentTypeController::update
 * @see app/Http/Controllers/AttachmentTypeController.php:70
 * @route '/attachment-types/{attachment_type}'
 */
update.put = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\AttachmentTypeController::update
 * @see app/Http/Controllers/AttachmentTypeController.php:70
 * @route '/attachment-types/{attachment_type}'
 */
update.patch = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AttachmentTypeController::update
 * @see app/Http/Controllers/AttachmentTypeController.php:70
 * @route '/attachment-types/{attachment_type}'
 */
    const updateForm = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AttachmentTypeController::update
 * @see app/Http/Controllers/AttachmentTypeController.php:70
 * @route '/attachment-types/{attachment_type}'
 */
        updateForm.put = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\AttachmentTypeController::update
 * @see app/Http/Controllers/AttachmentTypeController.php:70
 * @route '/attachment-types/{attachment_type}'
 */
        updateForm.patch = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AttachmentTypeController::destroy
 * @see app/Http/Controllers/AttachmentTypeController.php:85
 * @route '/attachment-types/{attachment_type}'
 */
export const destroy = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/attachment-types/{attachment_type}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AttachmentTypeController::destroy
 * @see app/Http/Controllers/AttachmentTypeController.php:85
 * @route '/attachment-types/{attachment_type}'
 */
destroy.url = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attachment_type: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    attachment_type: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        attachment_type: args.attachment_type,
                }

    return destroy.definition.url
            .replace('{attachment_type}', parsedArgs.attachment_type.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentTypeController::destroy
 * @see app/Http/Controllers/AttachmentTypeController.php:85
 * @route '/attachment-types/{attachment_type}'
 */
destroy.delete = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AttachmentTypeController::destroy
 * @see app/Http/Controllers/AttachmentTypeController.php:85
 * @route '/attachment-types/{attachment_type}'
 */
    const destroyForm = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AttachmentTypeController::destroy
 * @see app/Http/Controllers/AttachmentTypeController.php:85
 * @route '/attachment-types/{attachment_type}'
 */
        destroyForm.delete = (args: { attachment_type: string | number } | [attachment_type: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const attachmentTypes = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default attachmentTypes