import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\AttachmentController::index
 * @see app/Http/Controllers/AttachmentController.php:26
 * @route '/martyrs/{martyr}/attachments'
 */
export const index = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/martyrs/{martyr}/attachments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttachmentController::index
 * @see app/Http/Controllers/AttachmentController.php:26
 * @route '/martyrs/{martyr}/attachments'
 */
index.url = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { martyr: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { martyr: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    martyr: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        martyr: typeof args.martyr === 'object'
                ? args.martyr.id
                : args.martyr,
                }

    return index.definition.url
            .replace('{martyr}', parsedArgs.martyr.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentController::index
 * @see app/Http/Controllers/AttachmentController.php:26
 * @route '/martyrs/{martyr}/attachments'
 */
index.get = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttachmentController::index
 * @see app/Http/Controllers/AttachmentController.php:26
 * @route '/martyrs/{martyr}/attachments'
 */
index.head = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttachmentController::index
 * @see app/Http/Controllers/AttachmentController.php:26
 * @route '/martyrs/{martyr}/attachments'
 */
    const indexForm = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttachmentController::index
 * @see app/Http/Controllers/AttachmentController.php:26
 * @route '/martyrs/{martyr}/attachments'
 */
        indexForm.get = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttachmentController::index
 * @see app/Http/Controllers/AttachmentController.php:26
 * @route '/martyrs/{martyr}/attachments'
 */
        indexForm.head = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AttachmentController::create
 * @see app/Http/Controllers/AttachmentController.php:41
 * @route '/martyrs/{martyr}/attachments/create'
 */
export const create = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/martyrs/{martyr}/attachments/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttachmentController::create
 * @see app/Http/Controllers/AttachmentController.php:41
 * @route '/martyrs/{martyr}/attachments/create'
 */
create.url = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { martyr: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { martyr: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    martyr: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        martyr: typeof args.martyr === 'object'
                ? args.martyr.id
                : args.martyr,
                }

    return create.definition.url
            .replace('{martyr}', parsedArgs.martyr.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentController::create
 * @see app/Http/Controllers/AttachmentController.php:41
 * @route '/martyrs/{martyr}/attachments/create'
 */
create.get = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttachmentController::create
 * @see app/Http/Controllers/AttachmentController.php:41
 * @route '/martyrs/{martyr}/attachments/create'
 */
create.head = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttachmentController::create
 * @see app/Http/Controllers/AttachmentController.php:41
 * @route '/martyrs/{martyr}/attachments/create'
 */
    const createForm = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttachmentController::create
 * @see app/Http/Controllers/AttachmentController.php:41
 * @route '/martyrs/{martyr}/attachments/create'
 */
        createForm.get = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttachmentController::create
 * @see app/Http/Controllers/AttachmentController.php:41
 * @route '/martyrs/{martyr}/attachments/create'
 */
        createForm.head = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\AttachmentController::store
 * @see app/Http/Controllers/AttachmentController.php:52
 * @route '/martyrs/{martyr}/attachments'
 */
export const store = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/martyrs/{martyr}/attachments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AttachmentController::store
 * @see app/Http/Controllers/AttachmentController.php:52
 * @route '/martyrs/{martyr}/attachments'
 */
store.url = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { martyr: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { martyr: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    martyr: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        martyr: typeof args.martyr === 'object'
                ? args.martyr.id
                : args.martyr,
                }

    return store.definition.url
            .replace('{martyr}', parsedArgs.martyr.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentController::store
 * @see app/Http/Controllers/AttachmentController.php:52
 * @route '/martyrs/{martyr}/attachments'
 */
store.post = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AttachmentController::store
 * @see app/Http/Controllers/AttachmentController.php:52
 * @route '/martyrs/{martyr}/attachments'
 */
    const storeForm = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AttachmentController::store
 * @see app/Http/Controllers/AttachmentController.php:52
 * @route '/martyrs/{martyr}/attachments'
 */
        storeForm.post = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\AttachmentController::show
 * @see app/Http/Controllers/AttachmentController.php:63
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
export const show = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/martyrs/{martyr}/attachments/{attachment}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttachmentController::show
 * @see app/Http/Controllers/AttachmentController.php:63
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
show.url = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    martyr: args[0],
                    attachment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        martyr: typeof args.martyr === 'object'
                ? args.martyr.id
                : args.martyr,
                                attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return show.definition.url
            .replace('{martyr}', parsedArgs.martyr.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentController::show
 * @see app/Http/Controllers/AttachmentController.php:63
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
show.get = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttachmentController::show
 * @see app/Http/Controllers/AttachmentController.php:63
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
show.head = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttachmentController::show
 * @see app/Http/Controllers/AttachmentController.php:63
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
    const showForm = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttachmentController::show
 * @see app/Http/Controllers/AttachmentController.php:63
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
        showForm.get = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttachmentController::show
 * @see app/Http/Controllers/AttachmentController.php:63
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
        showForm.head = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\AttachmentController::edit
 * @see app/Http/Controllers/AttachmentController.php:79
 * @route '/martyrs/{martyr}/attachments/{attachment}/edit'
 */
export const edit = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/martyrs/{martyr}/attachments/{attachment}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AttachmentController::edit
 * @see app/Http/Controllers/AttachmentController.php:79
 * @route '/martyrs/{martyr}/attachments/{attachment}/edit'
 */
edit.url = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    martyr: args[0],
                    attachment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        martyr: typeof args.martyr === 'object'
                ? args.martyr.id
                : args.martyr,
                                attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return edit.definition.url
            .replace('{martyr}', parsedArgs.martyr.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentController::edit
 * @see app/Http/Controllers/AttachmentController.php:79
 * @route '/martyrs/{martyr}/attachments/{attachment}/edit'
 */
edit.get = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AttachmentController::edit
 * @see app/Http/Controllers/AttachmentController.php:79
 * @route '/martyrs/{martyr}/attachments/{attachment}/edit'
 */
edit.head = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AttachmentController::edit
 * @see app/Http/Controllers/AttachmentController.php:79
 * @route '/martyrs/{martyr}/attachments/{attachment}/edit'
 */
    const editForm = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AttachmentController::edit
 * @see app/Http/Controllers/AttachmentController.php:79
 * @route '/martyrs/{martyr}/attachments/{attachment}/edit'
 */
        editForm.get = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AttachmentController::edit
 * @see app/Http/Controllers/AttachmentController.php:79
 * @route '/martyrs/{martyr}/attachments/{attachment}/edit'
 */
        editForm.head = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\AttachmentController::update
 * @see app/Http/Controllers/AttachmentController.php:96
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
export const update = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/martyrs/{martyr}/attachments/{attachment}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\AttachmentController::update
 * @see app/Http/Controllers/AttachmentController.php:96
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
update.url = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    martyr: args[0],
                    attachment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        martyr: typeof args.martyr === 'object'
                ? args.martyr.id
                : args.martyr,
                                attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return update.definition.url
            .replace('{martyr}', parsedArgs.martyr.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentController::update
 * @see app/Http/Controllers/AttachmentController.php:96
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
update.put = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\AttachmentController::update
 * @see app/Http/Controllers/AttachmentController.php:96
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
update.patch = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\AttachmentController::update
 * @see app/Http/Controllers/AttachmentController.php:96
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
    const updateForm = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AttachmentController::update
 * @see app/Http/Controllers/AttachmentController.php:96
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
        updateForm.put = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\AttachmentController::update
 * @see app/Http/Controllers/AttachmentController.php:96
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
        updateForm.patch = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\AttachmentController::destroy
 * @see app/Http/Controllers/AttachmentController.php:112
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
export const destroy = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/martyrs/{martyr}/attachments/{attachment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AttachmentController::destroy
 * @see app/Http/Controllers/AttachmentController.php:112
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
destroy.url = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    martyr: args[0],
                    attachment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        martyr: typeof args.martyr === 'object'
                ? args.martyr.id
                : args.martyr,
                                attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return destroy.definition.url
            .replace('{martyr}', parsedArgs.martyr.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AttachmentController::destroy
 * @see app/Http/Controllers/AttachmentController.php:112
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
destroy.delete = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\AttachmentController::destroy
 * @see app/Http/Controllers/AttachmentController.php:112
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
    const destroyForm = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AttachmentController::destroy
 * @see app/Http/Controllers/AttachmentController.php:112
 * @route '/martyrs/{martyr}/attachments/{attachment}'
 */
        destroyForm.delete = (args: { martyr: number | { id: number }, attachment: number | { id: number } } | [martyr: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const attachments = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default attachments