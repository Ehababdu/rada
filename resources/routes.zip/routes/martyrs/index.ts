import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import exportMethod9280c6 from './export'
import attachments from './attachments'
/**
* @see \App\Http\Controllers\MartyrController::index
 * @see app/Http/Controllers/MartyrController.php:21
 * @route '/martyrs'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/martyrs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MartyrController::index
 * @see app/Http/Controllers/MartyrController.php:21
 * @route '/martyrs'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MartyrController::index
 * @see app/Http/Controllers/MartyrController.php:21
 * @route '/martyrs'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MartyrController::index
 * @see app/Http/Controllers/MartyrController.php:21
 * @route '/martyrs'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MartyrController::index
 * @see app/Http/Controllers/MartyrController.php:21
 * @route '/martyrs'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MartyrController::index
 * @see app/Http/Controllers/MartyrController.php:21
 * @route '/martyrs'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MartyrController::index
 * @see app/Http/Controllers/MartyrController.php:21
 * @route '/martyrs'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\MartyrController::create
 * @see app/Http/Controllers/MartyrController.php:41
 * @route '/martyrs/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/martyrs/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MartyrController::create
 * @see app/Http/Controllers/MartyrController.php:41
 * @route '/martyrs/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MartyrController::create
 * @see app/Http/Controllers/MartyrController.php:41
 * @route '/martyrs/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MartyrController::create
 * @see app/Http/Controllers/MartyrController.php:41
 * @route '/martyrs/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MartyrController::create
 * @see app/Http/Controllers/MartyrController.php:41
 * @route '/martyrs/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MartyrController::create
 * @see app/Http/Controllers/MartyrController.php:41
 * @route '/martyrs/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MartyrController::create
 * @see app/Http/Controllers/MartyrController.php:41
 * @route '/martyrs/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\MartyrController::store
 * @see app/Http/Controllers/MartyrController.php:57
 * @route '/martyrs'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/martyrs',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MartyrController::store
 * @see app/Http/Controllers/MartyrController.php:57
 * @route '/martyrs'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MartyrController::store
 * @see app/Http/Controllers/MartyrController.php:57
 * @route '/martyrs'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\MartyrController::store
 * @see app/Http/Controllers/MartyrController.php:57
 * @route '/martyrs'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MartyrController::store
 * @see app/Http/Controllers/MartyrController.php:57
 * @route '/martyrs'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\MartyrController::show
 * @see app/Http/Controllers/MartyrController.php:71
 * @route '/martyrs/{martyr}'
 */
export const show = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/martyrs/{martyr}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MartyrController::show
 * @see app/Http/Controllers/MartyrController.php:71
 * @route '/martyrs/{martyr}'
 */
show.url = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { martyr: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { martyr: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    martyr: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        martyr: typeof args.martyr === 'object'
                ? args.martyr.id
                : args.martyr,
                }

    return show.definition.url
            .replace('{martyr}', parsedArgs.martyr.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MartyrController::show
 * @see app/Http/Controllers/MartyrController.php:71
 * @route '/martyrs/{martyr}'
 */
show.get = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MartyrController::show
 * @see app/Http/Controllers/MartyrController.php:71
 * @route '/martyrs/{martyr}'
 */
show.head = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MartyrController::show
 * @see app/Http/Controllers/MartyrController.php:71
 * @route '/martyrs/{martyr}'
 */
    const showForm = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MartyrController::show
 * @see app/Http/Controllers/MartyrController.php:71
 * @route '/martyrs/{martyr}'
 */
        showForm.get = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MartyrController::show
 * @see app/Http/Controllers/MartyrController.php:71
 * @route '/martyrs/{martyr}'
 */
        showForm.head = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\MartyrController::edit
 * @see app/Http/Controllers/MartyrController.php:84
 * @route '/martyrs/{martyr}/edit'
 */
export const edit = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/martyrs/{martyr}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MartyrController::edit
 * @see app/Http/Controllers/MartyrController.php:84
 * @route '/martyrs/{martyr}/edit'
 */
edit.url = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { martyr: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { martyr: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    martyr: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        martyr: typeof args.martyr === 'object'
                ? args.martyr.id
                : args.martyr,
                }

    return edit.definition.url
            .replace('{martyr}', parsedArgs.martyr.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MartyrController::edit
 * @see app/Http/Controllers/MartyrController.php:84
 * @route '/martyrs/{martyr}/edit'
 */
edit.get = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MartyrController::edit
 * @see app/Http/Controllers/MartyrController.php:84
 * @route '/martyrs/{martyr}/edit'
 */
edit.head = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MartyrController::edit
 * @see app/Http/Controllers/MartyrController.php:84
 * @route '/martyrs/{martyr}/edit'
 */
    const editForm = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MartyrController::edit
 * @see app/Http/Controllers/MartyrController.php:84
 * @route '/martyrs/{martyr}/edit'
 */
        editForm.get = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MartyrController::edit
 * @see app/Http/Controllers/MartyrController.php:84
 * @route '/martyrs/{martyr}/edit'
 */
        editForm.head = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\MartyrController::update
 * @see app/Http/Controllers/MartyrController.php:102
 * @route '/martyrs/{martyr}'
 */
export const update = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/martyrs/{martyr}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\MartyrController::update
 * @see app/Http/Controllers/MartyrController.php:102
 * @route '/martyrs/{martyr}'
 */
update.url = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { martyr: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { martyr: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    martyr: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        martyr: typeof args.martyr === 'object'
                ? args.martyr.id
                : args.martyr,
                }

    return update.definition.url
            .replace('{martyr}', parsedArgs.martyr.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MartyrController::update
 * @see app/Http/Controllers/MartyrController.php:102
 * @route '/martyrs/{martyr}'
 */
update.put = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\MartyrController::update
 * @see app/Http/Controllers/MartyrController.php:102
 * @route '/martyrs/{martyr}'
 */
update.patch = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\MartyrController::update
 * @see app/Http/Controllers/MartyrController.php:102
 * @route '/martyrs/{martyr}'
 */
    const updateForm = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MartyrController::update
 * @see app/Http/Controllers/MartyrController.php:102
 * @route '/martyrs/{martyr}'
 */
        updateForm.put = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\MartyrController::update
 * @see app/Http/Controllers/MartyrController.php:102
 * @route '/martyrs/{martyr}'
 */
        updateForm.patch = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\MartyrController::destroy
 * @see app/Http/Controllers/MartyrController.php:129
 * @route '/martyrs/{martyr}'
 */
export const destroy = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/martyrs/{martyr}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\MartyrController::destroy
 * @see app/Http/Controllers/MartyrController.php:129
 * @route '/martyrs/{martyr}'
 */
destroy.url = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { martyr: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { martyr: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    martyr: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        martyr: typeof args.martyr === 'object'
                ? args.martyr.id
                : args.martyr,
                }

    return destroy.definition.url
            .replace('{martyr}', parsedArgs.martyr.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MartyrController::destroy
 * @see app/Http/Controllers/MartyrController.php:129
 * @route '/martyrs/{martyr}'
 */
destroy.delete = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\MartyrController::destroy
 * @see app/Http/Controllers/MartyrController.php:129
 * @route '/martyrs/{martyr}'
 */
    const destroyForm = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MartyrController::destroy
 * @see app/Http/Controllers/MartyrController.php:129
 * @route '/martyrs/{martyr}'
 */
        destroyForm.delete = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\MartyrController::exportMethod
 * @see app/Http/Controllers/MartyrController.php:142
 * @route '/martyrs/export'
 */
export const exportMethod = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: exportMethod.url(options),
    method: 'post',
})

exportMethod.definition = {
    methods: ["post"],
    url: '/martyrs/export',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MartyrController::exportMethod
 * @see app/Http/Controllers/MartyrController.php:142
 * @route '/martyrs/export'
 */
exportMethod.url = (options?: RouteQueryOptions) => {
    return exportMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MartyrController::exportMethod
 * @see app/Http/Controllers/MartyrController.php:142
 * @route '/martyrs/export'
 */
exportMethod.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: exportMethod.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\MartyrController::exportMethod
 * @see app/Http/Controllers/MartyrController.php:142
 * @route '/martyrs/export'
 */
    const exportMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: exportMethod.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MartyrController::exportMethod
 * @see app/Http/Controllers/MartyrController.php:142
 * @route '/martyrs/export'
 */
        exportMethodForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: exportMethod.url(options),
            method: 'post',
        })
    
    exportMethod.form = exportMethodForm
/**
* @see \App\Http\Controllers\MartyrController::updateStatus
 * @see app/Http/Controllers/MartyrController.php:118
 * @route '/martyrs/{martyr}/status'
 */
export const updateStatus = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

updateStatus.definition = {
    methods: ["patch"],
    url: '/martyrs/{martyr}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\MartyrController::updateStatus
 * @see app/Http/Controllers/MartyrController.php:118
 * @route '/martyrs/{martyr}/status'
 */
updateStatus.url = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { martyr: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { martyr: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    martyr: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        martyr: typeof args.martyr === 'object'
                ? args.martyr.id
                : args.martyr,
                }

    return updateStatus.definition.url
            .replace('{martyr}', parsedArgs.martyr.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MartyrController::updateStatus
 * @see app/Http/Controllers/MartyrController.php:118
 * @route '/martyrs/{martyr}/status'
 */
updateStatus.patch = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateStatus.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\MartyrController::updateStatus
 * @see app/Http/Controllers/MartyrController.php:118
 * @route '/martyrs/{martyr}/status'
 */
    const updateStatusForm = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MartyrController::updateStatus
 * @see app/Http/Controllers/MartyrController.php:118
 * @route '/martyrs/{martyr}/status'
 */
        updateStatusForm.patch = (args: { martyr: number | { id: number } } | [martyr: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateStatus.form = updateStatusForm
const martyrs = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
export: Object.assign(exportMethod, exportMethod9280c6),
updateStatus: Object.assign(updateStatus, updateStatus),
attachments: Object.assign(attachments, attachments),
}

export default martyrs