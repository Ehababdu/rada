import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\MartyrController::get
 * @see app/Http/Controllers/MartyrController.php:142
 * @route '/martyrs/export'
 */
export const get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: get.url(options),
    method: 'get',
})

get.definition = {
    methods: ["get","head"],
    url: '/martyrs/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MartyrController::get
 * @see app/Http/Controllers/MartyrController.php:142
 * @route '/martyrs/export'
 */
get.url = (options?: RouteQueryOptions) => {
    return get.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MartyrController::get
 * @see app/Http/Controllers/MartyrController.php:142
 * @route '/martyrs/export'
 */
get.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: get.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MartyrController::get
 * @see app/Http/Controllers/MartyrController.php:142
 * @route '/martyrs/export'
 */
get.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: get.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MartyrController::get
 * @see app/Http/Controllers/MartyrController.php:142
 * @route '/martyrs/export'
 */
    const getForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: get.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MartyrController::get
 * @see app/Http/Controllers/MartyrController.php:142
 * @route '/martyrs/export'
 */
        getForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: get.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MartyrController::get
 * @see app/Http/Controllers/MartyrController.php:142
 * @route '/martyrs/export'
 */
        getForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: get.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    get.form = getForm
/**
* @see \App\Http\Controllers\MartyrController::latest
 * @see app/Http/Controllers/MartyrController.php:168
 * @route '/martyrs/export/latest'
 */
export const latest = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: latest.url(options),
    method: 'get',
})

latest.definition = {
    methods: ["get","head"],
    url: '/martyrs/export/latest',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MartyrController::latest
 * @see app/Http/Controllers/MartyrController.php:168
 * @route '/martyrs/export/latest'
 */
latest.url = (options?: RouteQueryOptions) => {
    return latest.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MartyrController::latest
 * @see app/Http/Controllers/MartyrController.php:168
 * @route '/martyrs/export/latest'
 */
latest.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: latest.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MartyrController::latest
 * @see app/Http/Controllers/MartyrController.php:168
 * @route '/martyrs/export/latest'
 */
latest.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: latest.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MartyrController::latest
 * @see app/Http/Controllers/MartyrController.php:168
 * @route '/martyrs/export/latest'
 */
    const latestForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: latest.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MartyrController::latest
 * @see app/Http/Controllers/MartyrController.php:168
 * @route '/martyrs/export/latest'
 */
        latestForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: latest.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MartyrController::latest
 * @see app/Http/Controllers/MartyrController.php:168
 * @route '/martyrs/export/latest'
 */
        latestForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: latest.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    latest.form = latestForm
/**
* @see \App\Http\Controllers\MartyrController::status
 * @see app/Http/Controllers/MartyrController.php:198
 * @route '/martyrs/export/status'
 */
export const status = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(options),
    method: 'get',
})

status.definition = {
    methods: ["get","head"],
    url: '/martyrs/export/status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MartyrController::status
 * @see app/Http/Controllers/MartyrController.php:198
 * @route '/martyrs/export/status'
 */
status.url = (options?: RouteQueryOptions) => {
    return status.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MartyrController::status
 * @see app/Http/Controllers/MartyrController.php:198
 * @route '/martyrs/export/status'
 */
status.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MartyrController::status
 * @see app/Http/Controllers/MartyrController.php:198
 * @route '/martyrs/export/status'
 */
status.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: status.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MartyrController::status
 * @see app/Http/Controllers/MartyrController.php:198
 * @route '/martyrs/export/status'
 */
    const statusForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: status.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MartyrController::status
 * @see app/Http/Controllers/MartyrController.php:198
 * @route '/martyrs/export/status'
 */
        statusForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: status.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MartyrController::status
 * @see app/Http/Controllers/MartyrController.php:198
 * @route '/martyrs/export/status'
 */
        statusForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: status.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    status.form = statusForm
const exportMethod = {
    get: Object.assign(get, get),
latest: Object.assign(latest, latest),
status: Object.assign(status, status),
}

export default exportMethod