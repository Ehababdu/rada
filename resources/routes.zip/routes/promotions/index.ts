import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\PromotionController::index
 * @see app/Http/Controllers/PromotionController.php:20
 * @route '/promotions'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/promotions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PromotionController::index
 * @see app/Http/Controllers/PromotionController.php:20
 * @route '/promotions'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PromotionController::index
 * @see app/Http/Controllers/PromotionController.php:20
 * @route '/promotions'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PromotionController::index
 * @see app/Http/Controllers/PromotionController.php:20
 * @route '/promotions'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PromotionController::index
 * @see app/Http/Controllers/PromotionController.php:20
 * @route '/promotions'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PromotionController::index
 * @see app/Http/Controllers/PromotionController.php:20
 * @route '/promotions'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PromotionController::index
 * @see app/Http/Controllers/PromotionController.php:20
 * @route '/promotions'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\PromotionController::create
 * @see app/Http/Controllers/PromotionController.php:92
 * @route '/promotions/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/promotions/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PromotionController::create
 * @see app/Http/Controllers/PromotionController.php:92
 * @route '/promotions/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PromotionController::create
 * @see app/Http/Controllers/PromotionController.php:92
 * @route '/promotions/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PromotionController::create
 * @see app/Http/Controllers/PromotionController.php:92
 * @route '/promotions/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PromotionController::create
 * @see app/Http/Controllers/PromotionController.php:92
 * @route '/promotions/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PromotionController::create
 * @see app/Http/Controllers/PromotionController.php:92
 * @route '/promotions/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PromotionController::create
 * @see app/Http/Controllers/PromotionController.php:92
 * @route '/promotions/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\PromotionController::store
 * @see app/Http/Controllers/PromotionController.php:169
 * @route '/promotions'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/promotions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PromotionController::store
 * @see app/Http/Controllers/PromotionController.php:169
 * @route '/promotions'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PromotionController::store
 * @see app/Http/Controllers/PromotionController.php:169
 * @route '/promotions'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PromotionController::store
 * @see app/Http/Controllers/PromotionController.php:169
 * @route '/promotions'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PromotionController::store
 * @see app/Http/Controllers/PromotionController.php:169
 * @route '/promotions'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\PromotionController::show
 * @see app/Http/Controllers/PromotionController.php:192
 * @route '/promotions/{promotion}'
 */
export const show = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/promotions/{promotion}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PromotionController::show
 * @see app/Http/Controllers/PromotionController.php:192
 * @route '/promotions/{promotion}'
 */
show.url = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { promotion: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { promotion: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    promotion: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        promotion: typeof args.promotion === 'object'
                ? args.promotion.id
                : args.promotion,
                }

    return show.definition.url
            .replace('{promotion}', parsedArgs.promotion.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PromotionController::show
 * @see app/Http/Controllers/PromotionController.php:192
 * @route '/promotions/{promotion}'
 */
show.get = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PromotionController::show
 * @see app/Http/Controllers/PromotionController.php:192
 * @route '/promotions/{promotion}'
 */
show.head = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PromotionController::show
 * @see app/Http/Controllers/PromotionController.php:192
 * @route '/promotions/{promotion}'
 */
    const showForm = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PromotionController::show
 * @see app/Http/Controllers/PromotionController.php:192
 * @route '/promotions/{promotion}'
 */
        showForm.get = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PromotionController::show
 * @see app/Http/Controllers/PromotionController.php:192
 * @route '/promotions/{promotion}'
 */
        showForm.head = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\PromotionController::edit
 * @see app/Http/Controllers/PromotionController.php:217
 * @route '/promotions/{promotion}/edit'
 */
export const edit = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/promotions/{promotion}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PromotionController::edit
 * @see app/Http/Controllers/PromotionController.php:217
 * @route '/promotions/{promotion}/edit'
 */
edit.url = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { promotion: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { promotion: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    promotion: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        promotion: typeof args.promotion === 'object'
                ? args.promotion.id
                : args.promotion,
                }

    return edit.definition.url
            .replace('{promotion}', parsedArgs.promotion.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PromotionController::edit
 * @see app/Http/Controllers/PromotionController.php:217
 * @route '/promotions/{promotion}/edit'
 */
edit.get = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PromotionController::edit
 * @see app/Http/Controllers/PromotionController.php:217
 * @route '/promotions/{promotion}/edit'
 */
edit.head = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PromotionController::edit
 * @see app/Http/Controllers/PromotionController.php:217
 * @route '/promotions/{promotion}/edit'
 */
    const editForm = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PromotionController::edit
 * @see app/Http/Controllers/PromotionController.php:217
 * @route '/promotions/{promotion}/edit'
 */
        editForm.get = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PromotionController::edit
 * @see app/Http/Controllers/PromotionController.php:217
 * @route '/promotions/{promotion}/edit'
 */
        editForm.head = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\PromotionController::update
 * @see app/Http/Controllers/PromotionController.php:301
 * @route '/promotions/{promotion}'
 */
export const update = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/promotions/{promotion}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\PromotionController::update
 * @see app/Http/Controllers/PromotionController.php:301
 * @route '/promotions/{promotion}'
 */
update.url = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { promotion: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { promotion: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    promotion: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        promotion: typeof args.promotion === 'object'
                ? args.promotion.id
                : args.promotion,
                }

    return update.definition.url
            .replace('{promotion}', parsedArgs.promotion.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PromotionController::update
 * @see app/Http/Controllers/PromotionController.php:301
 * @route '/promotions/{promotion}'
 */
update.put = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\PromotionController::update
 * @see app/Http/Controllers/PromotionController.php:301
 * @route '/promotions/{promotion}'
 */
update.patch = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\PromotionController::update
 * @see app/Http/Controllers/PromotionController.php:301
 * @route '/promotions/{promotion}'
 */
    const updateForm = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PromotionController::update
 * @see app/Http/Controllers/PromotionController.php:301
 * @route '/promotions/{promotion}'
 */
        updateForm.put = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\PromotionController::update
 * @see app/Http/Controllers/PromotionController.php:301
 * @route '/promotions/{promotion}'
 */
        updateForm.patch = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\PromotionController::destroy
 * @see app/Http/Controllers/PromotionController.php:379
 * @route '/promotions/{promotion}'
 */
export const destroy = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/promotions/{promotion}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PromotionController::destroy
 * @see app/Http/Controllers/PromotionController.php:379
 * @route '/promotions/{promotion}'
 */
destroy.url = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { promotion: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { promotion: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    promotion: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        promotion: typeof args.promotion === 'object'
                ? args.promotion.id
                : args.promotion,
                }

    return destroy.definition.url
            .replace('{promotion}', parsedArgs.promotion.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PromotionController::destroy
 * @see app/Http/Controllers/PromotionController.php:379
 * @route '/promotions/{promotion}'
 */
destroy.delete = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\PromotionController::destroy
 * @see app/Http/Controllers/PromotionController.php:379
 * @route '/promotions/{promotion}'
 */
    const destroyForm = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PromotionController::destroy
 * @see app/Http/Controllers/PromotionController.php:379
 * @route '/promotions/{promotion}'
 */
        destroyForm.delete = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\PromotionController::confirm
 * @see app/Http/Controllers/PromotionController.php:347
 * @route '/promotions/{promotion}/confirm'
 */
export const confirm = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: confirm.url(args, options),
    method: 'post',
})

confirm.definition = {
    methods: ["post"],
    url: '/promotions/{promotion}/confirm',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PromotionController::confirm
 * @see app/Http/Controllers/PromotionController.php:347
 * @route '/promotions/{promotion}/confirm'
 */
confirm.url = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { promotion: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { promotion: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    promotion: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        promotion: typeof args.promotion === 'object'
                ? args.promotion.id
                : args.promotion,
                }

    return confirm.definition.url
            .replace('{promotion}', parsedArgs.promotion.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PromotionController::confirm
 * @see app/Http/Controllers/PromotionController.php:347
 * @route '/promotions/{promotion}/confirm'
 */
confirm.post = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: confirm.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PromotionController::confirm
 * @see app/Http/Controllers/PromotionController.php:347
 * @route '/promotions/{promotion}/confirm'
 */
    const confirmForm = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: confirm.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PromotionController::confirm
 * @see app/Http/Controllers/PromotionController.php:347
 * @route '/promotions/{promotion}/confirm'
 */
        confirmForm.post = (args: { promotion: number | { id: number } } | [promotion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: confirm.url(args, options),
            method: 'post',
        })
    
    confirm.form = confirmForm
const promotions = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
confirm: Object.assign(confirm, confirm),
}

export default promotions