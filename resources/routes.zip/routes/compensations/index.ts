import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\CompensationController::index
 * @see app/Http/Controllers/CompensationController.php:17
 * @route '/compensations'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/compensations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompensationController::index
 * @see app/Http/Controllers/CompensationController.php:17
 * @route '/compensations'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompensationController::index
 * @see app/Http/Controllers/CompensationController.php:17
 * @route '/compensations'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompensationController::index
 * @see app/Http/Controllers/CompensationController.php:17
 * @route '/compensations'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompensationController::index
 * @see app/Http/Controllers/CompensationController.php:17
 * @route '/compensations'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompensationController::index
 * @see app/Http/Controllers/CompensationController.php:17
 * @route '/compensations'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompensationController::index
 * @see app/Http/Controllers/CompensationController.php:17
 * @route '/compensations'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CompensationController::create
 * @see app/Http/Controllers/CompensationController.php:101
 * @route '/compensations/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/compensations/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompensationController::create
 * @see app/Http/Controllers/CompensationController.php:101
 * @route '/compensations/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompensationController::create
 * @see app/Http/Controllers/CompensationController.php:101
 * @route '/compensations/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompensationController::create
 * @see app/Http/Controllers/CompensationController.php:101
 * @route '/compensations/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompensationController::create
 * @see app/Http/Controllers/CompensationController.php:101
 * @route '/compensations/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompensationController::create
 * @see app/Http/Controllers/CompensationController.php:101
 * @route '/compensations/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompensationController::create
 * @see app/Http/Controllers/CompensationController.php:101
 * @route '/compensations/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\CompensationController::store
 * @see app/Http/Controllers/CompensationController.php:136
 * @route '/compensations'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/compensations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CompensationController::store
 * @see app/Http/Controllers/CompensationController.php:136
 * @route '/compensations'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompensationController::store
 * @see app/Http/Controllers/CompensationController.php:136
 * @route '/compensations'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CompensationController::store
 * @see app/Http/Controllers/CompensationController.php:136
 * @route '/compensations'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompensationController::store
 * @see app/Http/Controllers/CompensationController.php:136
 * @route '/compensations'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CompensationController::show
 * @see app/Http/Controllers/CompensationController.php:167
 * @route '/compensations/{compensation}'
 */
export const show = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/compensations/{compensation}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompensationController::show
 * @see app/Http/Controllers/CompensationController.php:167
 * @route '/compensations/{compensation}'
 */
show.url = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { compensation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { compensation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    compensation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        compensation: typeof args.compensation === 'object'
                ? args.compensation.id
                : args.compensation,
                }

    return show.definition.url
            .replace('{compensation}', parsedArgs.compensation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompensationController::show
 * @see app/Http/Controllers/CompensationController.php:167
 * @route '/compensations/{compensation}'
 */
show.get = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompensationController::show
 * @see app/Http/Controllers/CompensationController.php:167
 * @route '/compensations/{compensation}'
 */
show.head = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompensationController::show
 * @see app/Http/Controllers/CompensationController.php:167
 * @route '/compensations/{compensation}'
 */
    const showForm = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompensationController::show
 * @see app/Http/Controllers/CompensationController.php:167
 * @route '/compensations/{compensation}'
 */
        showForm.get = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompensationController::show
 * @see app/Http/Controllers/CompensationController.php:167
 * @route '/compensations/{compensation}'
 */
        showForm.head = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\CompensationController::edit
 * @see app/Http/Controllers/CompensationController.php:191
 * @route '/compensations/{compensation}/edit'
 */
export const edit = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/compensations/{compensation}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CompensationController::edit
 * @see app/Http/Controllers/CompensationController.php:191
 * @route '/compensations/{compensation}/edit'
 */
edit.url = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { compensation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { compensation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    compensation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        compensation: typeof args.compensation === 'object'
                ? args.compensation.id
                : args.compensation,
                }

    return edit.definition.url
            .replace('{compensation}', parsedArgs.compensation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompensationController::edit
 * @see app/Http/Controllers/CompensationController.php:191
 * @route '/compensations/{compensation}/edit'
 */
edit.get = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CompensationController::edit
 * @see app/Http/Controllers/CompensationController.php:191
 * @route '/compensations/{compensation}/edit'
 */
edit.head = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CompensationController::edit
 * @see app/Http/Controllers/CompensationController.php:191
 * @route '/compensations/{compensation}/edit'
 */
    const editForm = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CompensationController::edit
 * @see app/Http/Controllers/CompensationController.php:191
 * @route '/compensations/{compensation}/edit'
 */
        editForm.get = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CompensationController::edit
 * @see app/Http/Controllers/CompensationController.php:191
 * @route '/compensations/{compensation}/edit'
 */
        editForm.head = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\CompensationController::update
 * @see app/Http/Controllers/CompensationController.php:227
 * @route '/compensations/{compensation}'
 */
export const update = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/compensations/{compensation}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\CompensationController::update
 * @see app/Http/Controllers/CompensationController.php:227
 * @route '/compensations/{compensation}'
 */
update.url = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { compensation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { compensation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    compensation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        compensation: typeof args.compensation === 'object'
                ? args.compensation.id
                : args.compensation,
                }

    return update.definition.url
            .replace('{compensation}', parsedArgs.compensation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompensationController::update
 * @see app/Http/Controllers/CompensationController.php:227
 * @route '/compensations/{compensation}'
 */
update.put = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\CompensationController::update
 * @see app/Http/Controllers/CompensationController.php:227
 * @route '/compensations/{compensation}'
 */
update.patch = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CompensationController::update
 * @see app/Http/Controllers/CompensationController.php:227
 * @route '/compensations/{compensation}'
 */
    const updateForm = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompensationController::update
 * @see app/Http/Controllers/CompensationController.php:227
 * @route '/compensations/{compensation}'
 */
        updateForm.put = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\CompensationController::update
 * @see app/Http/Controllers/CompensationController.php:227
 * @route '/compensations/{compensation}'
 */
        updateForm.patch = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CompensationController::destroy
 * @see app/Http/Controllers/CompensationController.php:246
 * @route '/compensations/{compensation}'
 */
export const destroy = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/compensations/{compensation}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CompensationController::destroy
 * @see app/Http/Controllers/CompensationController.php:246
 * @route '/compensations/{compensation}'
 */
destroy.url = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { compensation: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { compensation: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    compensation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        compensation: typeof args.compensation === 'object'
                ? args.compensation.id
                : args.compensation,
                }

    return destroy.definition.url
            .replace('{compensation}', parsedArgs.compensation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CompensationController::destroy
 * @see app/Http/Controllers/CompensationController.php:246
 * @route '/compensations/{compensation}'
 */
destroy.delete = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CompensationController::destroy
 * @see app/Http/Controllers/CompensationController.php:246
 * @route '/compensations/{compensation}'
 */
    const destroyForm = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CompensationController::destroy
 * @see app/Http/Controllers/CompensationController.php:246
 * @route '/compensations/{compensation}'
 */
        destroyForm.delete = (args: { compensation: number | { id: number } } | [compensation: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const compensations = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default compensations